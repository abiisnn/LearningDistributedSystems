#include "SocketDatagram.h"
#include "PaqueteDatagrama.h"
#include "IP.h"
#include <cstring>
#include <iostream>
#include<bits/stdc++.h>
#define TAM 1000

using namespace std;

int main(void) {
	int time, res, last;
	string srt, firstPart, lastNumber;
	cin >> time >> res >> srt;
	IP ip(srt);
	firstPart = ip.getFirst();
	last = ip.getLast();
	while(1) {
		// ENVIAR SOLICITUD
		for(int i = 0, last = ip.getLast(); i < 1; i++, last++) {
			srt = firstPart + to_string(last);
			cout << "Enviando solicitud a: " << srt << endl; 			
    		char char_array[srt.length() + 1];   
    		strcpy(char_array, srt.c_str()); 
			
			// ENVIAR DATOS: i, resolucion
			SocketDatagrama c(7200);
			int datos[2];
			datos[0] = i; datos[1] = res;
			char envia[2*sizeof(int)];
			memcpy(envia, &datos, 2*sizeof(int));
			PaqueteDatagrama a((char*)envia, 2*sizeof(int), char_array, 7200);
			int p = c.envia(a);
			cout << "Tamaño de envio: " << p << endl;
			std::this_thread::sleep_for(std::chrono::milliseconds(70));
			
			// Recibir tamaño  y bandera
			PaqueteDatagrama b(2 * sizeof(int));
			try {
				int n = c.recibe(b);
				memcpy(datos, b.obtieneDatos(), 2 * sizeof(int));
				printf("Recibi bandera: %d\n", datos[0]);
				printf("Recibi tamaño de la imagen: %d\n", datos[1]);
				int size = datos[1];
				
				string nombreArchivo = to_string(i) + ".png";
				char char_array[nombreArchivo.length() + 1];   
    			strcpy(char_array, nombreArchivo.c_str()); 
		
				ofstream out(char_array, ios::binary);
				int contador = 0;
				for(int i = 0; i < size; i++) {
					cout << "Recibiendo paquete " << i << " de " << size << endl;
					// ESPERAR RESPUESTA
					PaqueteDatagrama d(TAM *  sizeof(char));
					try {
						int m = c.recibe(d);
						if(m != NULL) {
							char imagenRecibida[TAM];
							memcpy(imagenRecibida, d.obtieneDatos(), TAM * sizeof(int));
							printf("Recibi respuesta : %d\n", i);
							for(int j = 0; j < TAM; j++) {
								out.put(imagenRecibida[j]);
								contador++;
								if(imagenRecibida[j] == -1) {
									out.put(imagenRecibida[j]);
									out.close();
									break;
								}
							}
						}
						out.close();
					} catch(const char *mensaje) {
						std::cerr << mensaje << endl;
					}
				}
			} catch(const char *mensaje) {
				std::cerr << mensaje << endl;
			}
		}
		std::this_thread::sleep_for(std::chrono::milliseconds(time));
	}
	return 0;
}
